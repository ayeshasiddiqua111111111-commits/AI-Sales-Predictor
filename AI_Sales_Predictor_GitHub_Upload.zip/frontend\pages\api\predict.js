// Polynomial Regression (Degree 2) exact analytical weights trained on advertising.csv
const INTERCEPT = 5.1509434619278665;
const COEFFS = {
  tv: 0.0762164938449861,
  radio: -0.031983831901239976,
  newspaper: -0.0019202454090229205,
  tv_sq: -0.00010580787687797244,
  tv_radio: 0.0004185397070935095,
  tv_news: -0.000025541550730067905,
  radio_sq: 0.0014482031076616508,
  radio_news: 0.0001646914974942999,
  news_sq: 0.0000852684125374377
};

export function calculatePrediction(tvDollars, radioDollars, newspaperDollars) {
  const tv = Number(tvDollars) / 1000.0;
  const radio = Number(radioDollars) / 1000.0;
  const news = Number(newspaperDollars) / 1000.0;

  const prediction =
    INTERCEPT +
    COEFFS.tv * tv +
    COEFFS.radio * radio +
    COEFFS.newspaper * news +
    COEFFS.tv_sq * Math.pow(tv, 2) +
    COEFFS.tv_radio * (tv * radio) +
    COEFFS.tv_news * (tv * news) +
    COEFFS.radio_sq * Math.pow(radio, 2) +
    COEFFS.radio_news * (radio * news) +
    COEFFS.news_sq * Math.pow(news, 2);

  const synergyBoost = COEFFS.tv_radio * (tv * radio);

  return {
    predictionUnits: Math.max(0, prediction),
    synergyBoostUnits: synergyBoost,
    totalBudget: Number(tvDollars) + Number(radioDollars) + Number(newspaperDollars),
    scaledInputs: { tv, radio, news }
  };
}

export default function handler(req, res) {
  if (req.method === 'POST') {
    const { tv = 150000, radio = 25000, newspaper = 30000 } = req.body || {};
    const result = calculatePrediction(tv, radio, newspaper);

    return res.status(200).json({
      success: true,
      ...result,
      metrics: {
        r2Score: 0.9533,
        mae: 0.9034,
        rmse: 1.2011,
        modelType: 'Polynomial Regression (Degree = 2)'
      }
    });
  }

  return res.status(200).json({
    status: 'online',
    message: 'AI Sales Predictor API',
    model: 'Polynomial Regression (Degree 2)',
    r2Score: 0.9533
  });
}
