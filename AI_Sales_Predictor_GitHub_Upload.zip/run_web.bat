@echo off
echo ===================================================
echo Starting AI Sales Predictor (Next.js Application)...
echo ===================================================
echo Opening at: http://localhost:3000
echo.
cd /d "%~dp0frontend"
if not exist ".next" (
    echo Building production bundle...
    cmd /c "npm run build"
)
start http://localhost:3000
cmd /c "npm run start -- -H 0.0.0.0 -p 3000"
pause
