@echo off
echo Starting AI Sales Predictor Streamlit Web Application...
cd /d "%~dp0"
python -m streamlit run app.py --server.port 8501
pause
