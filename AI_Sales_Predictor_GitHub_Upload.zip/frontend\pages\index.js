import { useState, useMemo } from 'react';
import Head from 'next/head';
import advertisingData from '../data/advertising.json';

// Polynomial Regression (Degree = 2) Exact Coefficients
const INTERCEPT = 5.1509434619278665;
const COEFFS = {
  tv: 0.0762164938449861,
  radio: -0.031983831901239976,
  news: -0.0019202454090229205,
  tv_sq: -0.00010580787687797244,
  tv_radio: 0.0004185397070935095,
  tv_news: -0.000025541550730067905,
  radio_sq: 0.0014482031076616508,
  radio_news: 0.0001646914974942999,
  news_sq: 0.0000852684125374377
};

export default function HomePage() {
  // Input budgets in dollars ($)
  const [tv, setTv] = useState(150000);
  const [radio, setRadio] = useState(25000);
  const [newspaper, setNewspaper] = useState(30000);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState('predict');
  const [activePreset, setActivePreset] = useState('balanced');

  // Table explorer state
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState('Sales');
  const [sortAsc, setSortAsc] = useState(false);
  const pageSize = 10;

  // Preset scenarios
  const presets = [
    { id: 'balanced', label: 'Balanced Mix', tv: 150000, radio: 25000, news: 30000 },
    { id: 'radio_blitz', label: 'Radio Synergy Blitz', tv: 180000, radio: 45000, news: 10000 },
    { id: 'tv_dominant', label: 'Prime-Time TV Dominant', tv: 260000, radio: 15000, news: 15000 },
    { id: 'conservative', label: 'Lean Budget', tv: 60000, radio: 20000, news: 20000 }
  ];

  const applyPreset = (preset) => {
    setActivePreset(preset.id);
    setTv(preset.tv);
    setRadio(preset.radio);
    setNewspaper(preset.news);
  };

  // Real-time calculation using exact Polynomial Regression equation
  const calculation = useMemo(() => {
    const t = tv / 1000.0;
    const r = radio / 1000.0;
    const n = newspaper / 1000.0;

    const pred =
      INTERCEPT +
      COEFFS.tv * t +
      COEFFS.radio * r +
      COEFFS.news * n +
      COEFFS.tv_sq * Math.pow(t, 2) +
      COEFFS.tv_radio * (t * r) +
      COEFFS.tv_news * (t * n) +
      COEFFS.radio_sq * Math.pow(r, 2) +
      COEFFS.radio_news * (r * n) +
      COEFFS.news_sq * Math.pow(n, 2);

    const total = tv + radio + newspaper;
    const tvPct = total > 0 ? (tv / total) * 100 : 0;
    const radioPct = total > 0 ? (radio / total) * 100 : 0;
    const newsPct = total > 0 ? (newspaper / total) * 100 : 0;

    const synergyBoost = COEFFS.tv_radio * (t * r);

    // Marginal delta for an extra $1,000 in each channel
    const tvMarginal = COEFFS.tv + 2 * COEFFS.tv_sq * t + COEFFS.tv_radio * r + COEFFS.tv_news * n;
    const radioMarginal = COEFFS.radio + 2 * COEFFS.radio_sq * r + COEFFS.tv_radio * t + COEFFS.radio_news * n;
    const newsMarginal = COEFFS.news + 2 * COEFFS.news_sq * n + COEFFS.tv_news * t + COEFFS.radio_news * r;

    return {
      predictedUnits: Math.max(0, pred),
      totalBudget: total,
      tvPct,
      radioPct,
      newsPct,
      synergyBoost,
      tvMarginal,
      radioMarginal,
      newsMarginal
    };
  }, [tv, radio, newspaper]);

  // Filtered and sorted dataset
  const filteredData = useMemo(() => {
    let result = [...advertisingData];

    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (row) =>
          row.TV.toString().includes(q) ||
          row.Radio.toString().includes(q) ||
          row.Newspaper.toString().includes(q) ||
          row.Sales.toString().includes(q)
      );
    }

    result.sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];
      return sortAsc ? valA - valB : valB - valA;
    });

    return result;
  }, [searchQuery, sortField, sortAsc]);

  const totalPages = Math.ceil(filteredData.length / pageSize);
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage]);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  return (
    <>
      <Head>
        <title>AI Sales Predictor — Multi-Channel Marketing Forecast</title>
        <meta
          name="description"
          content="Interactive AI-powered marketing simulation dashboard predicting product sales from multi-channel advertising budgets using Polynomial Regression."
        />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>

      <div className="app-container">
        {/* Navigation Bar */}
        <header className="navbar">
          <div className="nav-brand">
            <div className="brand-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 3V21H21" stroke="#00f0ff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M19 9L14 14L10 10L4 16" stroke="#8b5cf6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div>
              <h1 className="brand-title">AI Sales Predictor</h1>
            </div>
            <span className="brand-tag">Next.js Engine</span>
          </div>

          <div className="nav-meta">
            <div className="meta-item">
              <span className="status-dot"></span>
              <span>Polynomial Regression (Deg 2)</span>
            </div>
            <div className="meta-item">
              <span style={{ color: '#00f0ff', fontWeight: '700' }}>R² 95.3%</span>
            </div>
          </div>
        </header>

        {/* Main Grid: Controls Sidebar + Content Panel */}
        <div className="dashboard-grid">
          {/* Left Column: Budget Controls */}
          <aside className="glass-panel">
            <div className="controls-header">
              <h2 className="panel-title">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#00f0ff" strokeWidth="2">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
                Campaign Controls
              </h2>
              <p className="panel-subtitle">
                Adjust multi-channel media budgets below to simulate real-time sales impact.
              </p>
            </div>

            {/* Quick Scenario Presets */}
            <div className="presets-container">
              <div className="presets-label">Strategy Presets</div>
              <div className="presets-grid">
                {presets.map((preset) => (
                  <button
                    key={preset.id}
                    className={`preset-btn ${activePreset === preset.id ? 'active' : ''}`}
                    onClick={() => applyPreset(preset)}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sliders */}
            <div className="sliders-wrapper">
              {/* TV Slider */}
              <div className="slider-group">
                <div className="slider-header">
                  <span className="slider-title">
                    <span className="channel-indicator tv"></span>
                    TV Budget
                  </span>
                  <span className="slider-value-display">${tv.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="300000"
                  step="1000"
                  value={tv}
                  onChange={(e) => {
                    setTv(Number(e.target.value));
                    setActivePreset(null);
                  }}
                  className="custom-slider"
                />
                <div className="slider-limits">
                  <span>$0</span>
                  <span>$300k</span>
                </div>
              </div>

              {/* Radio Slider */}
              <div className="slider-group">
                <div className="slider-header">
                  <span className="slider-title">
                    <span className="channel-indicator radio"></span>
                    Radio Budget
                  </span>
                  <span className="slider-value-display">${radio.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50000"
                  step="500"
                  value={radio}
                  onChange={(e) => {
                    setRadio(Number(e.target.value));
                    setActivePreset(null);
                  }}
                  className="custom-slider radio-slider"
                />
                <div className="slider-limits">
                  <span>$0</span>
                  <span>$50k</span>
                </div>
              </div>

              {/* Newspaper Slider */}
              <div className="slider-group">
                <div className="slider-header">
                  <span className="slider-title">
                    <span className="channel-indicator news"></span>
                    Newspaper Budget
                  </span>
                  <span className="slider-value-display">${newspaper.toLocaleString()}</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="120000"
                  step="500"
                  value={newspaper}
                  onChange={(e) => {
                    setNewspaper(Number(e.target.value));
                    setActivePreset(null);
                  }}
                  className="custom-slider news-slider"
                />
                <div className="slider-limits">
                  <span>$0</span>
                  <span>$120k</span>
                </div>
              </div>
            </div>

            {/* Aggregated Total Spend */}
            <div className="total-spend-card">
              <div className="total-spend-label">Total Campaign Investment</div>
              <div className="total-spend-value">${calculation.totalBudget.toLocaleString()}</div>

              {/* Visual allocation bar */}
              <div className="distribution-bar">
                <div className="bar-segment tv" style={{ width: `${calculation.tvPct}%` }}></div>
                <div className="bar-segment radio" style={{ width: `${calculation.radioPct}%` }}></div>
                <div className="bar-segment news" style={{ width: `${calculation.newsPct}%` }}></div>
              </div>

              <div className="distribution-legend">
                <span>TV {calculation.tvPct.toFixed(1)}%</span>
                <span>Radio {calculation.radioPct.toFixed(1)}%</span>
                <span>News {calculation.newsPct.toFixed(1)}%</span>
              </div>
            </div>
          </aside>

          {/* Right Column: Dynamic View Panels */}
          <main className="main-content">
            {/* Tabs Selector */}
            <nav className="tabs-nav" aria-label="Dashboard Views">
              <button
                className={`tab-button ${activeTab === 'predict' ? 'active' : ''}`}
                onClick={() => setActiveTab('predict')}
              >
                🔮 Prediction & Synergy
              </button>
              <button
                className={`tab-button ${activeTab === 'explorer' ? 'active' : ''}`}
                onClick={() => setActiveTab('explorer')}
              >
                📊 Dataset Explorer
              </button>
              <button
                className={`tab-button ${activeTab === 'diagnostics' ? 'active' : ''}`}
                onClick={() => setActiveTab('diagnostics')}
              >
                🧪 Model Diagnostics
              </button>
            </nav>

            {/* TAB 1: PREDICTION & SYNERGY */}
            {activeTab === 'predict' && (
              <>
                {/* Primary Output Hero Card */}
                <section className="prediction-hero-card">
                  <div className="hero-glow-accents"></div>
                  <div className="hero-content">
                    <div className="hero-text-block">
                      <div className="hero-badge">AI Forecast Output</div>
                      <h2 className="hero-title">Predicted Sales Performance</h2>
                      <p className="hero-desc">
                        Estimated market response based on 2nd-degree polynomial non-linear modeling with cross-channel synergy.
                      </p>
                    </div>
                    <div className="hero-output-box">
                      <div className="hero-output-label">Projected Units Sold</div>
                      <div className="hero-output-number">
                        {calculation.predictedUnits.toFixed(3)}
                        <span className="hero-output-unit">M units</span>
                      </div>
                    </div>
                  </div>
                </section>

                {/* Cross-Channel Synergy Banner */}
                <div className="synergy-banner">
                  <div className="synergy-text">
                    <div className="synergy-icon">⚡</div>
                    <div>
                      <div className="synergy-title">Channel Synergy Effect (TV × Radio Interaction)</div>
                      <div className="synergy-desc">
                        Combining TV with Radio amplifies brand recall, contributing non-linear sales uplift beyond independent linear spend.
                      </div>
                    </div>
                  </div>
                  <div className="synergy-badge">
                    +{calculation.synergyBoost.toFixed(3)}M units
                  </div>
                </div>

                {/* Marginal Channel Return Indicators */}
                <div className="insights-grid">
                  <div className="stat-card">
                    <div className="stat-header">
                      <span className="stat-title">TV Return Sensitivity</span>
                      <span className="channel-indicator tv"></span>
                    </div>
                    <div className="stat-value">
                      +{Math.max(0, calculation.tvMarginal * 1000).toFixed(0)}
                      <span style={{ fontSize: '0.85rem', color: '#94a3b8', fontWeight: '400', marginLeft: '4px' }}>units / +$1k</span>
                    </div>
                    <div className="stat-desc">
                      High volume reach; steady returns across baseline brand awareness campaigns.
                    </div>
                  </div>

                  <div className="stat-card">
                    <div className="stat-header">
                      <span className="stat-title">Radio Return Sensitivity</span>
                      <span className="channel-indicator radio"></span>
                    </div>
                    <div className="stat-value">
                      +{Math.max(0, calculation.radioMarginal * 1000).toFixed(0)}
                      <span style={{ fontSize: '0.85rem', color: '#94a3b8', fontWeight: '400', marginLeft: '4px' }}>units / +$1k</span>
                    </div>
                    <div className="stat-desc">
                      Highest marginal efficiency when paired concurrently with TV broadcast.
                    </div>
                  </div>

                  <div className="stat-card">
                    <div className="stat-header">
                      <span className="stat-title">Newspaper Return Sensitivity</span>
                      <span className="channel-indicator news"></span>
                    </div>
                    <div className="stat-value">
                      +{Math.max(0, calculation.newsMarginal * 1000).toFixed(0)}
                      <span style={{ fontSize: '0.85rem', color: '#94a3b8', fontWeight: '400', marginLeft: '4px' }}>units / +$1k</span>
                    </div>
                    <div className="stat-desc">
                      Marginal saturation; best suited for local coupons and targeted print promotions.
                    </div>
                  </div>
                </div>

                {/* Interactive SVG Chart: Spend vs Historical Campaigns */}
                <div className="chart-container">
                  <div className="chart-header">
                    <h3 className="chart-title">Current Allocation in Historical Context</h3>
                    <div className="chart-legend">
                      <div className="legend-item">
                        <span className="legend-dot data-points"></span>
                        <span>Past Campaigns (200 records)</span>
                      </div>
                      <div className="legend-item">
                        <span className="legend-dot current-point"></span>
                        <span>Your Simulated Campaign</span>
                      </div>
                    </div>
                  </div>

                  {/* SVG Visual Canvas */}
                  <svg viewBox="0 0 800 280" style={{ width: '100%', height: 'auto', overflow: 'visible' }}>
                    {/* Grid lines */}
                    {[60, 120, 180, 240].map((y) => (
                      <line key={y} x1="40" y1={y} x2="760" y2={y} stroke="rgba(255,255,255,0.05)" strokeDasharray="4" />
                    ))}

                    {/* Historical Scatter Dots */}
                    {advertisingData.map((d, i) => {
                      const totalSpend = d.TV + d.Radio + d.Newspaper;
                      const cx = 50 + (totalSpend / 450) * 700;
                      const cy = 250 - (d.Sales / 30) * 200;
                      return (
                        <circle
                          key={i}
                          cx={cx}
                          cy={cy}
                          r="3.5"
                          fill="rgba(0, 240, 255, 0.45)"
                          stroke="rgba(0, 240, 255, 0.7)"
                          strokeWidth="1"
                        />
                      );
                    })}

                    {/* Current Simulated Point */}
                    {(() => {
                      const currentTotalK = (tv + radio + newspaper) / 1000;
                      const cx = Math.min(760, Math.max(50, 50 + (currentTotalK / 450) * 700));
                      const cy = Math.min(250, Math.max(30, 250 - (calculation.predictedUnits / 30) * 200));

                      return (
                        <g>
                          {/* Core Dot */}
                          <circle cx={cx} cy={cy} r="10" fill="#ffffff" stroke="#8b5cf6" strokeWidth="3" />
                          {/* Tooltip Tag */}
                          <rect x={cx - 55} y={cy - 38} width="110" height="24" rx="6" fill="#0f172a" stroke="#00f0ff" strokeWidth="1" />
                          <text x={cx} y={cy - 22} fill="#ffffff" fontSize="11" fontWeight="700" textAnchor="middle">
                            {calculation.predictedUnits.toFixed(2)}M Units
                          </text>
                        </g>
                      );
                    })()}

                    {/* Axis Labels */}
                    <text x="50" y="270" fill="#64748b" fontSize="11">$0 Total Spend</text>
                    <text x="400" y="270" fill="#64748b" fontSize="11" textAnchor="middle">$225k Total Spend</text>
                    <text x="760" y="270" fill="#64748b" fontSize="11" textAnchor="end">$450k Total Spend</text>
                  </svg>
                </div>
              </>
            )}

            {/* TAB 2: DATASET EXPLORER */}
            {activeTab === 'explorer' && (
              <section className="glass-panel">
                <div className="explorer-controls">
                  <div>
                    <h3 className="panel-title">Advertising Campaign Dataset</h3>
                    <p className="panel-subtitle">200 real-world campaign records used for machine learning model training</p>
                  </div>

                  <input
                    type="text"
                    className="search-input-box"
                    placeholder="Search spend or sales..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setCurrentPage(1);
                    }}
                  />
                </div>

                {/* Data Table */}
                <div className="table-wrapper">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th onClick={() => handleSort('TV')}>
                          TV Budget ($k) {sortField === 'TV' ? (sortAsc ? '▲' : '▼') : ''}
                        </th>
                        <th onClick={() => handleSort('Radio')}>
                          Radio Budget ($k) {sortField === 'Radio' ? (sortAsc ? '▲' : '▼') : ''}
                        </th>
                        <th onClick={() => handleSort('Newspaper')}>
                          Newspaper Budget ($k) {sortField === 'Newspaper' ? (sortAsc ? '▲' : '▼') : ''}
                        </th>
                        <th onClick={() => handleSort('Sales')}>
                          Sales (M Units) {sortField === 'Sales' ? (sortAsc ? '▲' : '▼') : ''}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginatedData.map((row, idx) => (
                        <tr key={idx}>
                          <td style={{ color: '#64748b' }}>{(currentPage - 1) * pageSize + idx + 1}</td>
                          <td style={{ color: '#00f0ff', fontWeight: '600' }}>${row.TV.toFixed(1)}k</td>
                          <td style={{ color: '#8b5cf6', fontWeight: '600' }}>${row.Radio.toFixed(1)}k</td>
                          <td style={{ color: '#f43f5e', fontWeight: '600' }}>${row.Newspaper.toFixed(1)}k</td>
                          <td style={{ fontWeight: '700', color: '#ffffff' }}>{row.Sales.toFixed(1)}M</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination Controls */}
                <div className="pagination-bar">
                  <span>
                    Showing {(currentPage - 1) * pageSize + 1} to{' '}
                    {Math.min(currentPage * pageSize, filteredData.length)} of {filteredData.length} records
                  </span>

                  <div className="pagination-actions">
                    <button
                      className="page-btn"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    >
                      Previous
                    </button>
                    <span style={{ padding: '0.4rem 0.6rem', color: '#ffffff' }}>
                      Page {currentPage} of {totalPages || 1}
                    </span>
                    <button
                      className="page-btn"
                      disabled={currentPage >= totalPages}
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                    >
                      Next
                    </button>
                  </div>
                </div>
              </section>
            )}

            {/* TAB 3: MODEL DIAGNOSTICS & FORMULATION */}
            {activeTab === 'diagnostics' && (
              <section className="glass-panel">
                <h3 className="panel-title" style={{ marginBottom: '1.25rem' }}>
                  Machine Learning Model Diagnostics
                </h3>

                {/* High-Level Metric Boxes */}
                <div className="metrics-row">
                  <div className="metric-badge-box highlight">
                    <div className="metric-title">R² Score (Accuracy)</div>
                    <div className="metric-val">95.33%</div>
                  </div>
                  <div className="metric-badge-box">
                    <div className="metric-title">Mean Absolute Error (MAE)</div>
                    <div className="metric-val">0.903</div>
                  </div>
                  <div className="metric-badge-box">
                    <div className="metric-title">Root Mean Squared (RMSE)</div>
                    <div className="metric-val">1.201</div>
                  </div>
                  <div className="metric-badge-box">
                    <div className="metric-title">Training Records</div>
                    <div className="metric-val">200</div>
                  </div>
                </div>

                {/* Polynomial Equation Viewer */}
                <div className="equation-card">
                  <div className="presets-label">2nd-Degree Polynomial Regression Equation</div>
                  <div className="equation-display">
                    Sales = 5.151 + (0.0762 × TV) - (0.0320 × Radio) - (0.0019 × News)
                    <br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- (0.000106 × TV²) +
                    <strong style={{ color: '#8b5cf6' }}> (0.000419 × TV × Radio) </strong>
                    - (0.000026 × TV × News)
                    <br />
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ (0.001448 × Radio²) + (0.000165 × Radio × News) + (0.000085 × News²)
                  </div>

                  <table className="term-table">
                    <thead>
                      <tr>
                        <th>Term Variable</th>
                        <th>Fitted Coefficient Weight</th>
                        <th>Effect Classification</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Base Intercept (β₀)</td>
                        <td>5.150943</td>
                        <td>Baseline organic sales without advertising</td>
                      </tr>
                      <tr>
                        <td>TV (Linear)</td>
                        <td>+0.076216</td>
                        <td>Strong primary linear driver</td>
                      </tr>
                      <tr>
                        <td>TV × Radio (Synergy)</td>
                        <td className="term-synergy">+0.000419</td>
                        <td className="term-synergy">Key Cross-Channel Synergy Driver (Multiplicative Lift)</td>
                      </tr>
                      <tr>
                        <td>Radio² (Quadratic)</td>
                        <td>+0.001448</td>
                        <td>Positive acceleration at scale</td>
                      </tr>
                      <tr>
                        <td>TV² (Quadratic)</td>
                        <td>-0.000106</td>
                        <td>Subtle diminishing returns at very high TV expenditure</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {/* Footer */}
            <footer className="app-footer">
              <div>AI Sales Predictor Next.js App — Powered by Polynomial Regression ML</div>
              <div>Local Dev Port: 3000 • Streamlit Port: 8501</div>
            </footer>
          </main>
        </div>
      </div>
    </>
  );
}
