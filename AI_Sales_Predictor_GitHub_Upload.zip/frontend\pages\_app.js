import '../styles/globals.css';

export default function MyApp({ Component, pageProps }) {
  return (
    <>
      <div className="app-backdrop-glow" />
      <Component {...pageProps} />
    </>
  );
}
